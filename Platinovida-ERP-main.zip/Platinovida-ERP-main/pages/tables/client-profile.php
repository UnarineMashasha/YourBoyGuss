<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title> Platinovida | User Profile</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="../../plugins/toastr/toastr.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="../../index.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge"><!--messages number--></span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <!-- <div class="media">
              <img src="../../dist/img/avatar.jpg" alt="User Avatar" class="img-size-50 mr-3 img-circle">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Brad Diesel
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">Call me whenever you can...</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div> -->
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <!-- <div class="media">
              <img src="../../dist/img/avatar.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  John Pierce
                  <span class="float-right text-sm text-muted"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">I got your message bro</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div> -->
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <!-- <div class="media">
              <img src="../../dist/img/avatar.jpg" alt="User Avatar" class="img-size-50 img-circle mr-3">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Nora Silvester
                  <span class="float-right text-sm text-warning"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm">The subject goes here</p>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i> 4 Hours Ago</p>
              </div>
            </div> -->
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <!-- <a href="#" class="dropdown-item dropdown-footer">See All Messages</a> -->
        </div>
      </li>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge"><!--notification number--></span>
        </a>
        <!-- <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">15 Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 new messages
            <span class="float-right text-muted text-sm">3 mins</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 friend requests
            <span class="float-right text-muted text-sm">12 hours</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 new reports
            <span class="float-right text-muted text-sm">2 days</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div> -->
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../../index.php" class="brand-link">
      <img src="../../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">Platinovida</span>

    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          
        </div>
        <div class="info">
          <a href="#" class="d-block"></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="../../index.php" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
        
          <li class="nav-item">
            <a href="javascript:void(0)" class="nav-link">
              <i class="nav-icon fas fa-folder"></i>
              <p>
                Projects
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../../pages/examples/project-add.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Project Add</p>
                </a>
              </li>        
              <li class="nav-item">
                <a href="../../pages/examples/projects.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Project Detail</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="../../pages/calendar.html" class="nav-link">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>
                Events
                <span class="badge badge-info right">2</span>
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="javascript:void(0)" class="nav-link">
              <i class="nav-icon fas fa-table"></i>
              <p>
                Clients Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../../pages/tables/data.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Clients Information</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../../pages/tables/add-client.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add a Client</p>
                </a>
              </li>
            </ul>
          </li>
        
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-envelope"></i>
              <p>
                Mailbox
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../../pages/mailbox/mailbox.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Inbox</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../../pages/mailbox/compose.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Compose</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../../pages/mailbox/read-mail.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Read</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="../../pages/examples/contacts.html" class="nav-link">
              <i class="far fa-address-book nav-icon"></i>
              <p>Members</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="../../pages/examples/profile.html" class="nav-link">
              <i class="far fa-user nav-icon"></i>
              <p>My account</p>
            </a>
          </li>

          <li class="nav-header">MISCELLANEOUS</li>

          <li class="nav-item">
            <a href="../../pages/examples/faq.html" class="nav-link">
              <i class="far fa-circle nav-icon"></i>
              <p>FAQ</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../../pages/gallery.html" class="nav-link">
              <i class="nav-icon far fa-image"></i>
              <p>
                Gallery
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="../../dist/php/logout.php" class="nav-link">
              <i class="nav-icon fas fa-sign-out-alt"></i>
              <p>
                Logout
              </p>
            </a>
          </li>
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Client Account</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Client Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="../../dist/img/avatar.jpg"
                       alt="Client profile picture">
                </div>

                <h3 class="profile-username text-center"><!--dynamic client name --></h3>

                <p class="text-muted text-center profile-contact"><!-- client contact--></p>
              </div>
              <!-- /.card-body -->
            </div>
            
            <!-- /.card -->

            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">Activity</a></li>
                  <li class="nav-item"><a class="nav-link" href="#timeline" data-toggle="tab">Information</a></li>
                  <li class="nav-item"><a class="nav-link" href="#amountpaid" data-toggle="tab">Payment History</a></li>
                  
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="active tab-pane" id="activity">
                    <a href="#" style="margin-bottom: 30px" class="btn btn-primary btn-xm add-activity" data-toggle="modal" data-target="#modal-default">Add an activity</a>
                    <!-- Post -->

                    <!-- /.post -->
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="timeline">
                    <!-- The timeline -->
                    <div class="card card-warning">
              
                      <!-- /.card-header -->
                      <div class="card-body">
                        <form id="update-client-form">
                          <input type="hidden" name="request" value="update client information">
                          <input type="hidden" name="cID" id="cID">
                          <div class="row">
                            <div class="col-sm-6">
                              <!-- text input -->
                              <div class="form-group">
                                <label>Company Name</label>
                                <input type="text" name="company" id="cName" class="form-control update-client-inputs" disabled required>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" id="cDescription" class="form-control update-client-inputs" rows="1" disabled required></textarea>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-sm-6">
                              <!-- textarea -->
                              <div class="form-group">
                                <label>Industry</label>
                                <input type="text" name="industry" id="cIndustry" class="form-control update-client-inputs" disabled required>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="form-group">
                                <label>Country</label>
                                <input type="text" name="country" id="cCountry" class="form-control update-client-inputs" disabled required>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-sm-6">
                              <!-- textarea -->
                              <div class="form-group">
                                <label>Contact</label>
                                <input type="text" name="contact" id="cContact" class="form-control update-client-inputs" disabled required>
                              </div>
                            </div>
                            <div class="col-sm-6">
                              <div class="form-group">
                                <label>Email</label>
                                <input type="text" name="email" id="cEmail" class="form-control update-client-inputs" disabled required>
                              </div>
                            </div>
                          </div>
                          <a href="javascript:void(0)" class="btn btn-primary btn-sm edit-client-info-btn">Edit information</a>

                          <button style="display: none;" id="update-client-btn" class="btn btn-info btn-sm"><i class="fas fa-pencil-alt"></i>  Update</button>

                          <a href="javascript:void(0)" id="delete-client-btn" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i>  Delete</a>

                        </form>
                      </div>
                      <!-- /.card-body -->
                    </div>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="amountpaid">
                    <!-- Invoices -->
                    <a href="#" style="margin-bottom: 30px" class="btn btn-primary btn-xm add-activity" data-toggle="modal" data-target="#invoices-modal-default">Add an invoice</a>

                    <section class="content">
                      <div class="container-fluid">
                        
                        <div class="row">
                          <div class="col-12">
                            <div class="card">
                             
                              <!-- /.card-header -->
                              <div class="card-body">
                                <table id="client_invoices" class="table table-bordered table-hover table-striped">
                                  <thead>
                                    <tr>
                                      <th></th>
                                      <th>Date</th>
                                      <th>Reference</th>
                                      <th></th>
                                      <th></th>
                                      <th></th>
                                      <th></th>

                                    </tr>
                                  </thead>
                                  <tbody>
                                    <!-- clients invoices are loaded here -->
                                  </tbody>
                                  
                                </table>
                              </div>
                              <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                           
                            <!-- /.card -->
                          </div>
                          <!-- /.col -->
                        </div>
                        <!-- /.row -->
                      </div>
                      <!-- /.container-fluid -->
                    </section>
                  </div>

                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <!-- receive notif from url -->

    <!-- <div class="upload-flag">
     
    </div> -->

    <!-- modal add activity -->
    <div class="modal fade" id="modal-default">
      <div class="modal-dialog">
        <form enctype="multipart/form-data" class="modal-content" id="clients-activites-form">
          <div class="modal-header">
            <h4 class="modal-title">Add an activity</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
              
            <div class="card-body">
              
              <div class="row">
                <div class="col-sm">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Title<span title="required field" class="required-input">*</span></label>
                    <input type="text" name="title_activity" class="form-control activity-field" placeholder="Title">                    
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-sm">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Date<span title="required field" class="required-input">*</span></label>
                    <input type="date" name="date_activity" class="form-control activity-field">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm">
                  <!-- textarea -->
                  <div class="form-group">
                    <label>Activity<span title="required field" class="required-input">*</span></label>
                    <textarea name="activity" class="form-control activity-field" rows="3" placeholder="Enter ..."></textarea>
                  </div>
                </div>
                
              </div>
              <!-- <div class="form-group">
                <label for="exampleInputFile">Add files</label>
                <div class="input-group">
                  <div class="custom-file">
                    
                    <input type="file" id="files_activity" name="files_activity[]" multiple>

                  </div>
                </div>
              </div>  --> 
            </div>
            <!-- /.card-body -->
          </div>
          <div class="modal-footer justify-content-between">
            <!-- will store client id just to pass it to jquery -->
            <input type="hidden" name="client_id" id="client_id">
            <input type="hidden" name="request" value="set client activity">

            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary add-activity-btn">Add activity</button>
          </div>
        </form>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>

    <!-- modal add invoices -->
    <div class="modal fade" id="invoices-modal-default">
      <div class="modal-dialog">
        <form enctype="multipart/form-data" class="modal-content" id="invoice-form">
          <div class="modal-header">
            <h4 class="modal-title">Add an invoice</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="card-body">
              
              <div class="row">
                <div class="col-sm">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Date<span title="required field" class="required-input">*</span></label>
                    <input type="date" name="invoiceDate" class="form-control invoice-field" required>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm">
                  <!-- textarea -->
                  <div class="form-group">
                    <label>Reference<span title="required field" class="required-input">*</span></label>
                    <input type="text" name="invoiceRef" class="form-control invoice-field" required>
                  </div>
                </div>
                
              </div>
              <div class="form-group">
                <label>Add a file<span title="required field" class="required-input">*</span></label>
                <div class="input-group">
                  <div class="custom-file">
                    <input type="file" name="anInvoice" accept=".pdf, .docx, .ms-excel" class="invoice-field invoice-file" required>
                  </div>
                </div>
              </div>  
            </div>
            <!-- /.card-body -->
          </div>
          <div class="modal-footer justify-content-between">
            <!-- will store client id just to pass it to jquery -->
            <input type="hidden" name="clientIdInvoice" id="client-id-invoice">
            <input type="hidden" name="request" value="set client invoice">

            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary add-invoice-btn">Add an invoice</button>
          </div>
        </form>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.1.0
    </div>
    <strong>Copyright &copy; 2021 <a href="https://adminlte.io">Platinovida</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- custom js -->
<script src="../../dist/js/requests.js"></script>
<!-- Admin App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- Toastr -->
<script src="../../plugins/toastr/toastr.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../plugins/jszip/jszip.min.js"></script>
<script src="../../plugins/pdfmake/pdfmake.min.js"></script>
<script src="../../plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  $(function(){

    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const clientId = urlParams.get('id');
    document.getElementById('client_id').value = clientId;
    document.getElementById('client-id-invoice').value = clientId;


    // get a client info
    (function (){
        const request = 'get 1 client info';
        const clientID = $('#client_id').val();

        $.ajax({
            url: '../../dist/php/request.php',
            type: "POST",
            data: {request:request, clientID:clientID},
            cache: false,
            success: function(data){
                let results = jQuery.parseJSON(data);
                
                if(data == 304){
                  toastr.error("Information not available. Please try again later.");
                }
                else{
                  
                  $('.profile-username').text(results.company);
                  $('.profile-contact').text(results.contact);

                  $('#cName').val(results.company);
                  $('#cDescription').text(results.description);
                  $('#cIndustry').val(results.industry);
                  $('#cCountry').val(results.country);
                  $('#cContact').val(results.contact);
                  $('#cEmail').val(results.email);
                }
            }
        });
    })();

    $('.edit-client-info-btn').click(function() {
      $(this).css('display', 'none');
      $('#delete-client-btn').css('display', 'none');
      $('#update-client-btn').css('display', 'inline-block');

      for(let i = 0; i < 6; i++){
        document.getElementsByClassName('update-client-inputs')[i].disabled = false;
      }
    })

    $('#update-client-btn').click(function(){
      let myForm = document.querySelector('#update-client-form');
      $(myForm).submit(function(e){
          e.preventDefault();
      });

      var emptyInput = 0;

      for(let i = 0; i < 6; i++){

        if (document.getElementsByClassName('update-client-inputs')[i].value == "") {
          emptyInput = emptyInput + 1;
          break;
        }
      }
      
      if(emptyInput > 0){
        toastr.error("Please fill up all fields or N/A for an empty field.");
      }else{

        let clientID = $('#client_id').val();
        document.getElementById('cID').value = clientID;

        $.ajax({
          url: '../../dist/php/request.php',
          type: 'POST',
          data: new FormData(myForm),
          contentType: false,
          cache: false,
          processData: false,
          success: function(data){
              if(data == 202){
                // hide update btn, show edit & delete btns
                $('#update-client-btn').css('display', 'none');
                $('.edit-client-info-btn').css('display', 'inline-block');
                $('#delete-client-btn').css('display', 'inline-block');
                // disable all fields
                for(let i = 0; i < 6; i++){
                  document.getElementsByClassName('update-client-inputs')[i].disabled = true;
                };
                //send success message
                toastr.success("Information updated <strong>successfully</strong>. Please refresh the page.");
              }
              else{
                toastr.error("Informations could not be updated. Please try again later.");
              }
          }
        });
      }
    })

    $('#delete-client-btn').click(function() {
      if(confirm('Are you sure you want to delete this client? All information related will be deleted.')){

        const request = 'delete client';
        const clientID = $('#client_id').val();

        $.ajax({
            url: '../../dist/php/request.php',
            type: "POST",
            data: {request:request, clientID:clientID},
            cache: false,
            success: function(data){
                
                if(data == 202){
                  window.location.replace("data.html");
                  
                }
                else{
                  toastr.error("Please try again later.");
                }
            }
        });

      }
    })

    // set clients activities
    $('.add-activity-btn').click(function(){
      
      let myForm = document.querySelector('#clients-activites-form');
      
      $(myForm).submit(function(e){
          e.preventDefault();
      });

      let err = 0;
      for(let i = 0; i < 3; i++){

        if (document.getElementsByClassName('activity-field')[i].value == "") {
          err = err + 1;
          break;
        }
      }
      
      if(err > 0){
        toastr.error("Please fill up all required fields or N/A for an empty field.");
      }else{
        $.ajax({
          url:"../../dist/php/upload-activity.php",
          type: "POST",
          data: new FormData(myForm),
          cache: false,
          contentType: false,
          processData: false,
          success: function(data){
            let resp = jQuery.parseJSON(data);
            if(resp.code == 202){
              // clear input fields
              for(let i = 0; i < 3; i++){
                document.getElementsByClassName('activity-field')[i].value = "";
              }

              toastr.success(resp.message);
            }else{
              toastr.error(resp.message);
            }
            
          }
        });
      }
    });

    // get a client activities
    (function (){
      const request = 'get client activities';      

      $.ajax({
          url: '../../dist/php/request.php',
          type: "POST",
          data: {request:request, clientId:clientId},
          cache: false,
          success: function(data){              
              if(data == 304){
                // toastr.error("Information not available. Please try again later.");
              }
              else{
                
                $('#activity').append(data);
                
              }
          }
      });
    })();

    // delete activity
    $(document).on('click', '.delete-activity-btn', function(event) {
      if(confirm('Are you sure you want to delete this activity?')){

        const request = 'delete activity';
        const idActivity = $(this).data('id-activity');


        $.ajax({
            url: '../../dist/php/request.php',
            type: "POST",
            data: {request:request, idActivity:idActivity},
            cache: false,
            success: function(data){
                
                if(data == 202){
                  $('.activity'+idActivity).css('display', 'none');
                  toastr.success("Activity deleted <strong>successfully</strong>.");
                }
                else{
                  toastr.error("An error occured. Please try again later.");
                  // console.log(data);
                }
            }
        });

      }
    });

    (function (){
      const request = 'get client invoices';
      
      $.ajax({
          url: '../../dist/php/request.php',
          type: "POST",
          data: {request:request, clientId:clientId},
          cache: false,
          success: function(data){
              let results = jQuery.parseJSON(data);
              if(results == 304){
                $('#client_invoices tbody').text("No record for the moment. Add an invoice.");
              }else{
                // clients info tables
                $("#client_invoices").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "aaData":results,
                    "columnDefs":[
                        {
                            "targets":[0],
                            "visible": false,
                            "searchable": false,
                        },
                        {
                            "targets":[3],
                            "visible": false,
                            "searchable": false,
                        },
                        {
                            "targets":[4],
                            "visible": false,
                            "searchable": false,
                        },
                        {
                            "targets":[5],
                            "visible": false,
                            "searchable": false,
                        },
                        {
                            "targets":[6],
                            "sortable": false,
                            "searchable": false,
                        }
                    ]
                });
                
              }
          }
      });
    })();

    $('.add-invoice-btn').click(function(){
      const myForm = document.querySelector('#invoice-form');
      $(myForm).submit(function(e){
          e.preventDefault();
      });

      let newInvoice = document.querySelector('.invoice-file').value;
      let totalFiles = document.querySelector('.invoice-file').files.length;
      let file = document.querySelector('.invoice-file').files;
      let ext_allowed = ['pdf', 'docx'];
      
      var emptyInput = 0;

      for(let i = 0; i < 3; i++){

        if (document.getElementsByClassName('invoice-field')[i].value == "") {
          emptyInput = emptyInput + 1;
          break;
        }
      }
      
      if(emptyInput > 0){
        toastr.error("Please fill up all fields or N/A for an empty field.");
      }else{

        if (totalFiles > 0) {
          for(let x = 0; x < totalFiles; x++){
            let file_name = file[x].name;
            let ext = file_name.split('.').pop().toLowerCase();

            if (jQuery.inArray(ext, ext_allowed) !== -1) {
                
                let file_size = file[x].size || file[x].fileSize;
                
                if (file_size <= 12000000) {
                    $.ajax({
                        url: '../../dist/php/new-invoice.php',
                        type: "POST",
                        data: new FormData(myForm),
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(data){
                          let resp = jQuery.parseJSON(data);
                          if(resp.code == 202){

                            // clear input fields
                            for(let i = 0; i < 3; i++){
                              document.getElementsByClassName('invoice-field')[i].value = "";
                            }
                            toastr.success(resp.message);
                          }
                          else{
                            toastr.error(resp.message);
                          }
                          
                        }
                    });
                }
                else{
                  //return alert-danger for file too large
                  toastr.warning("Your file is too large.");
                }
            }
            else{
              //return alert-danger for invalid extension
              toastr.warning("Your file extension is not supported.");
            }
          }
        }
        
      }
    });

    // delete invoice
    $(document).on('click', '.delete-invoice-btn', function(event) {
      if(confirm('Are you sure you want to delete this invoice?')){

        const request = 'delete invoice';
        const invoiceId = $(this).data('invoice-id');
        const invoice = $(this).data('invoice');

        $.ajax({
            url: '../../dist/php/request.php',
            type: "POST",
            data: {request:request, invoiceId:invoiceId, invoice:invoice},
            cache: false,
            success: function(data){
                
                if(data == 202){
                  toastr.success("Invoice deleted <strong>successfully</strong>. Please refresh the page.");
                }
                else{
                  toastr.error("An error occured. Please try again later.");
                  
                }
            }
        });

      }
    });


})

</script>
</body>
</html>