<?php
require('');
if($_SESSION['ROLE']!=1){
    header('location:add_employee.php?id='.$_SESSION['USER_ID']);
    die();
}

$department='';
$id='';
if(isset($_GET['id'])){
    $id=mysqli_real_escape_string($con,$_GET['id']);
    $res=mysqli_query($con,"select * from department where id='$id'");
    $row=mysqli_fetch_assoc($res);
    $department=$row['department'];
}
if(isset($_POST['department'])){
    $department=mysqli_real_escape_string($con,$_GET['id']);
    if($id>0){
        $sql="update department set department='$department' where id='$id'";

    }else{
        $sql="insert into department(department) values('$department')";
    }
    mysqli_query($con,$sql);
	header('location:index.php');
	die();
}

?>